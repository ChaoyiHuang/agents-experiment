## A2A Multi-Agent Host

Google ADK-based host agent that can communicate with other agents over the A2A protocol.


## Prerequisites

- Python 3.12 or higher
- uv

## Running the agent

For running instructions, please see the [demo/README.md](/demo/README.md).