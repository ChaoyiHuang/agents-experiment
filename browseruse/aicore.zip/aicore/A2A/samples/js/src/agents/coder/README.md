# Coder Agent

This is a simple code-writing agent that emits full code files as artifacts. Start it with:

```bash
export GEMINI_API_KEY=<your_api_key>
npm run agents:coder
```

This will start up the agent on `http://localhost:41241/`.
