def main():
    print("Hello from aicore!")


if __name__ == "__main__":
    main()
